package addresses;

/*******
 * <p> Title: UnitedStatesAddress Class </p>
 * 
 * <p> Description: This class inherits the common data from its parent class and display the address belongs to it </p>
 * 
 * <p> Copyright: Lynn Robert Carter © 2018-08-20 </p>
 * 
 * @author Sanchit
 * 
 * 
 * @version 1.10	A set of classes that support an array of Indian addresses
 * Updated Date 2018-08-20 
 * 
 */

public class IndiaAddress extends GenericAddress {
	
	protected String state;
	protected String zipcode;

	/**********
	 * Default constructor
	 * 
	 */
	public IndiaAddress() {
		super();
	}

	
	/**********
	 * Fully-specified constructor
	 * 
	 * @param n - University Name
	 * @param a - Address
	 * @param c - City
	 * @param z - zipcode
	 * @param s - State
	 * @param cn - Country Name
	 * 
	 */
	public IndiaAddress(String n, String a, String c, String z, String s, String cn) {
		super(n, a, c, cn);
		state = s;
		zipcode = z;
	}
	
	/**********
	 * Overridden toString method for this class showing the values of all of the attributes
	 * 
	 * @return a string formatted to show the address in format appropriate for the United States
	 */
	
	public String toString() {
		return name + "\n" + address  + "\n" + city + ", " + zipcode + " " + state + "\n" + country;
	}
}
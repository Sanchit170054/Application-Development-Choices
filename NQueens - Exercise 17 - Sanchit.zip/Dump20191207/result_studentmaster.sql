-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: localhost    Database: result
-- ------------------------------------------------------
-- Server version	8.0.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `studentmaster`
--

DROP TABLE IF EXISTS `studentmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `studentmaster` (
  `studentRollNo` varchar(50) NOT NULL,
  `studentName` varchar(45) NOT NULL,
  `studentFather` varchar(45) DEFAULT NULL,
  `year` varchar(45) NOT NULL,
  `semester` varchar(45) NOT NULL,
  PRIMARY KEY (`studentRollNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `studentmaster`
--

LOCK TABLES `studentmaster` WRITE;
/*!40000 ALTER TABLE `studentmaster` DISABLE KEYS */;
INSERT INTO `studentmaster` VALUES ('170001','AMIT DHINGRA','KULWANT SINGH','year3','Semester 1'),('170002','Sumit kumar','SURESH KUMAR','year3','Semester 1'),('170003','KALLURU UMAMAHESWAR REDDY','K RAVI KUMAR REDDY','year3','Semester 1'),('170004','GODUGUCHINTHALA JAWAHAR','G RAGHUBATH','year3','Semester 1'),('170005','SAWAN GABA','SURINDER GABA','year3','Semester 1'),('170006','Vaibhav Mehandiratta','Krishan Mehandiratta','year3','Semester 1'),('170007','MUSKAAN','VIJAY KUMAR SEHGAL','year3','Semester 1'),('170008','HARSHIT','VIJAY KUMAR GUPTA','year3','Semester 1'),('170009','Manisha Bambal','RAMESH','year3','Semester 1'),('170010','Monika Bambal','SURESH','year3','Semester 1'),('170011','Piyush Malhotra','HARISH MALHOTRA','year3','Semester 1'),('170012','SIMARANJEET SINGH','BHARPUR NAGINA SINGH','year3','Semester 1'),('170013','PRINCE PARIHAR','Kapoor Chand','year3','Semester 1'),('170014','SHIVI MITTAL','Subhash Gupta','year3','Semester 1'),('170015','Manpreet Singh Kohli','BALWINDER SINGH','year3','Semester 1'),('170016','CHANPREET SINGH','BALWINDER SINGH','year3','Semester 1'),('170017','YASHUL AGGARWAL','Sandeep Aggarwal','year3','Semester 1'),('170018','GARVIT KUMAR','Jatindar Kumar','year3','Semester 1'),('170019','JASJEET SINGH','Jaspal Singh','year3','Semester 1'),('170020','Arjun Dutta','Neeraj Dutta','year3','Semester 1'),('170021','UJJWAL ANAND','JITENDRA KUMAR SINGH','year3','Semester 1'),('170022','ANSHUL','SURESH KUMAR','year3','Semester 1'),('170023','SUMIT SINGH','SHAKTI SINGH','year3','Semester 1'),('170024','AASTIK GAUTAM','ARUN KUMAR GAUTAM','year3','Semester 1'),('170025','KESHAV SHARMA','PARMOD KUMAR SHARMA','year3','Semester 1'),('170026','SUKRUT NAMDEV PATIL','NAMDEV SUBBARAO PATIL','year3','Semester 1'),('170027','JASKIRAT SINGH GREWAL','MANPREET SINGH GREWAL','year3','Semester 1'),('170028','NIPUN KATARIA','ANIL KATARIA','year3','Semester 1'),('170029','PURSHARTH GUJRAL','JAGDISH LAL GUJRAL','year3','Semester 1'),('170030','Shivam Singhal','Lokesh Singhal','year3','Semester 1'),('170031','NAMAN SINGLA','JAI BHAGWAN SINGLA','year3','Semester 1'),('170032','Vaibhav','Joginder Kumar','year3','Semester 1'),('170033','SPARSH GOEL','PAWAN KUMAR','year3','Semester 1'),('170034','Vinit','Sushil Kumar','year3','Semester 1'),('170036','DEEPESH KHURANA','MAHESH KHURANA','year3','Semester 1'),('170037','SAURABH MISHRA','MANISHANKAR MISHRA','year3','Semester 1'),('170038','VAIBHAV KUMAR MISHRA','BRIENDRA KUMAR MISHRA','year3','Semester 1'),('170040','PREETINDER SINGH','BALWINDER SINGH','year3','Semester 1'),('170041','PASUPULETI NIKHIL','','year3','Semester 1'),('170042','SAKSHAM BANSAL','ARUN GUPTA','year3','Semester 1'),('170043','ABHINAV SINGH YADAV','RADHEY SHYAM YADAV','year3','Semester 1'),('170044','Hemant Sah','Rajakishor Sah','year3','Semester 1'),('170047','Hiteshwar Sahai','Mukesh Kumar','year3','Semester 1'),('170049','Mohan Akshay Bhogadi','','year3','Semester 1'),('170051','Surender Kumar','Rakesh Kumar','year3','Semester 1'),('170052','Mansi','Satish Kumar','year3','Semester 1'),('170053','Yash','Raj Singh','year3','Semester 1'),('170054','Sanchit','Manoj Kumar','year3','Semester 1'),('170056','Puneet Garg','Davinder Garg','year3','Semester 1'),('170057','Shubham Walia','Gopal Walia','year3','Semester 1'),('170058','NAVNEET KUMAR SINGH','Pankaj Prasoon','year3','Semester 1'),('170059','DOLLY CHANDEL','RAVINDER KUMAR','year3','Semester 1');
/*!40000 ALTER TABLE `studentmaster` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-07 12:20:18

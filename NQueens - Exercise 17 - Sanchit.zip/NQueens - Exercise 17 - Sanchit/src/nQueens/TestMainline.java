package nQueens;

import java.util.ArrayList;

public class TestMainline {

	public static void main(String[] args) {
		GameBoard Test5By5 = new GameBoard(5);
		Test5By5.place(2, 2);
		System.out.println("Author Name:  Sanchit");
		System.out.println(Test5By5);;
	
	}

}

package nQueens;

import java.util.ArrayList;

public class TestMainline {

	public static void main(String[] args) {
		GameBoard size5 = new GameBoard(5);
		System.out.println("Author Name: Sanchit");
		ArrayList<GameBoard> solution = new ArrayList<GameBoard>();
	    size5.getAllSolutions();
		System.out.println(size5.getAllSolutions());
	
		
		
	}

}

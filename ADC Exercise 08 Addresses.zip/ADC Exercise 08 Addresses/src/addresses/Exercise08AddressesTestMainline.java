package addresses;

public class Exercise08AddressesTestMainline {

	public static void main(String[] args) {
		
		// Demonstrate that the United States Address holds the data and prints it properly
		UnitedStatesAddress LRCarterAddress = new UnitedStatesAddress (
				"Lynn Robert Carter",
				"3857 East Equestrian Trail",
				"Phoenix",
				"Arizona",
				"85044-3008",
				"USA");
		
		// Demonstrate that the Qatar Address holds the data and prints it properly
		QatarBusinessAddress CMUQatarAddress = new QatarBusinessAddress (
				"Office of Undergraduate Admissions",
				"Carnegie Mellon University",
				"c/o Qatar Foundation",
				"P.O. Box 24866",
				"Doha",
				"Qatar");
		
		// Demonstrate that the India Address holds the data and prints it properly
		
		IndiaAdress IndianAdress = new IndiaAdress (  //Variable to hold the Indian address
				"Maharishi Markandeshwar (Deemed to be University),",
				"Ambala - Yamunanagar Highway,",
				"Mullana-Ambala",
				"133-207",
				"(Haryana)",
				"India");
		
		// The following display the information stored above in a format appropriate for mailing
		System.out.println(LRCarterAddress);
		System.out.println();
		System.out.println(CMUQatarAddress);
	
		System.out.println(); // provide the space of one line
		System.out.println(IndianAdress); // print the address stores in the loacal variable
		
	}
}
package addresses;

/*******
 * <p> Title: UnitedStatesAddress Class </p>
 * 
 * <p> Description: This class inherits the common data from its parent class and display the address belongs to it </p>
 * 
 * <p> Copyright: Lynn Robert Carter © 2018-08-20 </p>
 * 
 * @author Sanchit
 * 
 * Date: 22/08/2018
 * 
 * @version 1.00	2018-08-20 A set of classes that support an array of different kinds of addresses
 * 
 */

public class IndiaAdress extends GenericAddress {
	
	protected String state;
	protected String zipcode;

	/**********
	 * Default constructor
	 * 
	 */
	public IndiaAdress() {
		super();
	}

	
	/**********
	 * Fully-specified constructor
	 * 
	 * @param n - University Name
	 * @param a - Address
	 * @param c - City
	 * @param z - zipcode
	 * @param s - State
	 * @param cn - Country Name
	 * 
	 */
	public IndiaAdress(String n, String a, String c, String z, String s, String cn) {
		super(n, a, c, cn);
		state = s;
		zipcode = z;
	}
	
	/**********
	 * Overridden toString method for this class showing the values of all of the attributes
	 * 
	 * @return a string formatted to show the address in format appropriate for the United States
	 */
	
	public String toString() {
		return name + "\n" + address  + "\n" + city + ", " + zipcode + " " + state + "\n" + country;
	}
}